import {Component, Inject, OnInit} from '@angular/core';
import {AbstractControl, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {CommonService} from '../../../shared/services/common.service';
import {CreateAndUpdateModalComponent} from '../../inquiry/create-and-update-modal/create-and-update-modal.component';

@Component({
  selector: 'app-orders-form',
  templateUrl: './orders-form.component.html'
})
export class OrdersFormComponent implements OnInit {
  form!: FormGroup;
  mode = 'Create';
  isSubmitted = false;
  selectedProduct!: string;
  supplierHolder: any[] = [];
  selectedSupplierId!: number;
  constructor(
    public dialogRef: MatDialogRef<CreateAndUpdateModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private commonService: CommonService
  ) {
  }

  getSupplierList(){
    this.commonService.getRequest('').subscribe((result) => {
      this.supplierHolder = result;
    })
  }

  ngOnInit(): void {
    const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const phoneRegex = /^[0-9]{10}$/;
    this.form = this.fb.group({
      id: [null],
      supplieR_ID: ['', [Validators.required]],
      address: ['', [Validators.required]],
      mobilE_NO: ['', [Validators.required, Validators.pattern(phoneRegex)]],
      raW_MATERIAL_NAME: ['', [Validators.required]],
      quantity: ['', [Validators.required]],
      rate: ['', [Validators.required]],
      tax: ['', [Validators.required]],

      // email: ['', [Validators.required, Validators.pattern(emailRegex)]],
      // customerName: ['', [Validators.required]],
      // productName: ['', [Validators.required]],
      // gstRate: ['', [Validators.required]],
      // totalAmount: ['', [Validators.required]],
      // orderDate: ['', [Validators.required]],
    });


    if (this.data) {
      console.log('Edit Data : ', this.data);
      this.mode = 'Update';
      this.form.patchValue({
        id: this.data.id,
        supplieR_ID: this.data.supplieR_ID,
        address: this.data.address,
        mobilE_NO: this.data.mobilE_NO,
        raW_MATERIAL_NAME: this.data.raW_MATERIAL_NAME,
        quantity: this.data.quantity,
        rate: this.data.rate,
        tax: this.data.tax,
      });

      console.log('patchValue : ', this.form.value);

    }
  }

  get f(): { [key: string]: AbstractControl } {
    return this.form.controls;
  }

  onSubmit(): void {
    console.log('Form Data : ', this.form.value);
    this.isSubmitted = true;
    if (this.form.invalid) {
      return;
    }

    if(this.selectedSupplierId){
      this.form.patchValue({
        supplieR_ID: this.selectedSupplierId
      })
    }else{
      alert('Please Select Supplier');
      return;
    }
    this.commonService.postRequest('PurchaseOrderDetails/CreateOrUpdateProductorder', this.form.value).subscribe((resp) => {
      console.log('Save Resp', resp);
      this.dialogRef.close(true);
    });

  }
}
