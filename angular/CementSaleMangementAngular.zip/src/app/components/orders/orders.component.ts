import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {FormBuilder} from '@angular/forms';
import {MatSort} from '@angular/material/sort';
import {CommonService} from '../../shared/services/common.service';
import {MatDialog} from '@angular/material/dialog';
import {OrdersFormComponent} from './orders-form/orders-form.component';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html'
})
export class OrdersComponent implements OnInit {
  displayedColumns = ['id', 'customerName', 'email', 'phone', 'productName', 'quantity', 'rate', 'gstRate', 'totalAmount', 'orderDate', 'actions'];
  dataSource: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private commonService: CommonService, private fb: FormBuilder, public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.getUserList();
  }

  getUserList(): void {
    const input = {
      maxResultCount: 100,
      skipCount: 0,
    };
    const data = [
      {
        id: 1,
        customerName: 'Chand Singh Ramroop',
        customerAddress: '71, Ambika Villas, Chandpole Mumbai - 540456',
        email: 'ram@gmail.com',
        phone: '9899058826',
        productName: 'Acc Cement',
        quantity: '450 sackful',
        rate: '400 / sackful',
        gstRate: '28%',
        totalAmount: '180000',
        orderDate: '26-06-2022',
      },
      {
        id: 2,
        customerName: 'Ajay Satish Chopra',
        customerAddress: '66, Subhash Apartments, RadhikaPur Thiruvananthapuram - 355480',
        email: 'ajay@gmail.com',
        phone: '9529861652',
        productName: 'Birla Cement',
        quantity: '350 sackful',
        rate: '400 / sackful',
        gstRate: '28%',
        totalAmount: '140000',
        orderDate: '26-06-2022',
      }
    ];
    this.dataSource = data;
    this.commonService.postRequest('', input).subscribe((result) => {
      console.log('fetchUserList : ', result);
      this.dataSource = result.items;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  add(): void {
    const dialogRef = this.dialog.open(OrdersFormComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after insert : ', result);
      if (result) {
        this.getUserList();
      }
    });
  }

  edit(editData: any): void {
    console.log('Edit Data : ', editData);
    const dialogRef = this.dialog.open(OrdersFormComponent, {
      data: editData,
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after update : ', result);
      if (result) {
        this.getUserList();
      }
    });
  }

  delete(id: any): void {
    this.commonService.deleteRequestWithId('', id).subscribe((data) => {
      console.log('User Delete Resp : ', data);
      this.getUserList();
    });
  }
}
