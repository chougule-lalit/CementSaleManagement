import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {FormBuilder} from '@angular/forms';
import {MatSort} from '@angular/material/sort';
import {CommonService} from '../../shared/services/common.service';
import {MatDialog} from '@angular/material/dialog';
import {WorkersFormComponent} from './workers-form/workers-form.component';

@Component({
  selector: 'app-workers',
  templateUrl: './workers.component.html'
})
export class WorkersComponent implements OnInit {

  displayedColumns = ['id', 'firstName', 'middleName', 'lastName', 'joiningDate', 'dob', 'experience', 'phone', 'actions'];
  dataSource: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private commonService: CommonService, private fb: FormBuilder, public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.getData();
  }

  getData(): void {
    const input = {
      maxResultCount: 100,
      skipCount: 0,
    };

    const data = [
      {
        id: 1,
        firstName: 'Chirag',
        middleName: 'Ram',
        lastName: 'Sarin',
        joiningDate: 'Sept 12, 2017',
        dob: 'August 26, 1996',
        experience: '5',
        phone: '+91 968 6012380',
      },
      {
        id: 2,
        firstName: 'Rupesh',
        middleName: 'Chandra',
        lastName: 'Pau',
        joiningDate: 'Jan 23, 2015',
        dob: 'December 9, 1992',
        experience: '7',
        phone: '+91 96 33978423',
      }
    ];
    this.dataSource = data;
    this.commonService.postRequest('UserMaster/fetchUserList', input).subscribe((result) => {
      console.log('Get Data : ', result);
      // this.dataSource = result.items;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  add(): void {
    const dialogRef = this.dialog.open(WorkersFormComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after insert : ', result);
      if (result) {
        this.getData();
      }
    });
  }

  edit(editData: any): void {
    console.log('Edit Data : ', editData);
    const dialogRef = this.dialog.open(WorkersFormComponent, {
      data: editData,
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after update : ', result);
      if (result) {
        this.getData();
      }
    });
  }

  delete(id: any): void {
    this.commonService.deleteRequestWithId('', id).subscribe((data) => {
      console.log('Delete Resp : ', data);
      this.getData();
    });
  }

}
