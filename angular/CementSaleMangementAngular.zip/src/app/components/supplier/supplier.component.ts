import {Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {FormBuilder} from '@angular/forms';
import {MatSort} from '@angular/material/sort';
import {CommonService} from '../../shared/services/common.service';
import {MatDialog} from '@angular/material/dialog';
import {SupplierFormComponent} from './supplier-form/supplier-form.component';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html'
})
export class SupplierComponent implements OnInit {

  displayedColumns = ['id', 'supplierName', 'supplierAddress', 'productName', 'email', 'phone', 'actions'];
  dataSource: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private commonService: CommonService, private fb: FormBuilder, public dialog: MatDialog) {
  }

  ngOnInit(): void {
    this.getUserList();
  }

  getUserList(): void {
    const input = {
      maxResultCount: 100,
      skipCount: 0,
    };

    const data = [
      {
        id: 1,
        supplierName: 'Saurabh Mody',
        supplierAddress: '91, Qadim Apartments, Hinjewadi Meerut - 169122',
        productName: 'Prism Cement',
        email: 'saurabh@gmail.com',
        phone: '+91 85 69564338',
      },
      {
        id: 2,
        supplierName: 'Manoj Ram Chandra',
        supplierAddress: '10, Kharadi, Raipur - 567991',
        productName: 'Prism Cement',
        email: ' rau.sukriti@khanna.com',
        phone: '+91 640 6486494',
      }
    ];
    this.dataSource = data;
    this.commonService.postRequest('', input).subscribe((result) => {
      console.log('Listing Data : ', result);
      // this.dataSource = result.items;
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }

  add(): void {
    const dialogRef = this.dialog.open(SupplierFormComponent);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after insert : ', result);
      if (result) {
        this.getUserList();
      }
    });
  }

  edit(editData: any): void {
    console.log('Edit Data : ', editData);
    const dialogRef = this.dialog.open(SupplierFormComponent, {
      data: editData,
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed after update : ', result);
      if (result) {
        this.getUserList();
      }
    });
  }

  delete(id: any): void {
    this.commonService.postRequest('', id).subscribe((data) => {
      console.log('User Delete Resp : ', data);
      this.getUserList();
    });
  }
}
