export const environment = {
  production: true,
  ApiBaseUrl: 'https://localhost:44324/',
};
